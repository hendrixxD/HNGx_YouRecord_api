from django.apps import AppConfig


class ChromeExtAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chrome_ext_app'
