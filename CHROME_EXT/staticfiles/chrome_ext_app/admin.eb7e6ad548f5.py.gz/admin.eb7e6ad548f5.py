from django.contrib import admin
from .models import Recordings

# Register your models here.
admin.register(Recordings)
